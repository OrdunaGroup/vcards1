(function ($) {
    "use strict";
        $('#table').DataTable({
            "order": [[0, "asc"]]
        });
        $('#table-plan').DataTable();
})(jQuery);
